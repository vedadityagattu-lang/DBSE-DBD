"""Apply the packaged menu update using the existing backend configuration."""
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT / 'backend')
sys.path.insert(0, str(ROOT / 'backend'))

from sqlalchemy import text
from app.database import engine

sql_path = ROOT / 'database' / 'upgrade_menu_v4.sql'
statements = [line for line in sql_path.read_text(encoding='utf-8').splitlines()
              if not line.lstrip().startswith('--')]
try:
    with engine.begin() as connection:
        for statement in '\n'.join(statements).split(';'):
            statement = statement.strip()
            if statement.upper() in ('USE DINE_DB', 'START TRANSACTION', 'COMMIT') or not statement:
                continue
            connection.execute(text(statement))
        count = connection.execute(text('SELECT COUNT(*) FROM menu_items')).scalar_one()
    print(f'Menu updated successfully. {count} menu items in the database.')
    print('Existing orders, tables, payments and menu IDs were preserved.')
except Exception as error:
    print(f'Menu update failed: {type(error).__name__}. Check MySQL and backend/.env.')
    sys.exit(1)
