USE dine_db;
INSERT INTO restaurant_tables(table_number,qr_token,status,is_active) VALUES
(1,'TBL-A9F31K','AVAILABLE',1),(2,'TBL-K2M84Q','AVAILABLE',1),(3,'TBL-P7X52R','AVAILABLE',1),(4,'TBL-C4V19N','AVAILABLE',1),
(5,'TBL-H8D63W','AVAILABLE',1),(6,'TBL-R5J27B','AVAILABLE',1),(7,'TBL-G3L91T','AVAILABLE',1),(8,'TBL-N6Q48Y','AVAILABLE',1),
(9,'TBL-S2E75M','AVAILABLE',1),(10,'TBL-V9K34P','AVAILABLE',1),(11,'TBL-B7R62C','AVAILABLE',1),(12,'TBL-M4T88H','AVAILABLE',1)
ON DUPLICATE KEY UPDATE qr_token=VALUES(qr_token),is_active=VALUES(is_active);
INSERT INTO categories(name,sort_order) VALUES ('Starters',1),('Main Course',2),('Breads & Rice',3),('Beverages',4),('Desserts',5)
ON DUPLICATE KEY UPDATE sort_order=VALUES(sort_order);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Crispy Corn','Golden fried corn tossed with peppers and chilli.',229,'/menu/crispy-corn.jpg',1,1,1,12 FROM categories c WHERE c.name='Starters'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Paneer Tikka','Grilled paneer cubes with peppers and tandoori spices.',289,'/menu/paneer-tikka.jpg',1,1,1,12 FROM categories c WHERE c.name='Starters'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Chicken 65','Spicy fried chicken tossed with curry leaves.',319,'/menu/chicken-65.jpg',0,1,1,12 FROM categories c WHERE c.name='Starters'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Samosa','Crisp pastry filled with spiced potatoes and peas.',79,'/menu/samosa.jpg',1,1,0,12 FROM categories c WHERE c.name='Starters'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Onion Pakora','Crispy onion fritters in a seasoned gram-flour batter.',149,'/menu/onion-pakora.jpg',1,1,0,12 FROM categories c WHERE c.name='Starters'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Hara Bhara Kebab','Pan-fried spinach and vegetable patties with a cheese centre.',219,'/menu/hara-bhara-kebab.jpg',1,1,0,12 FROM categories c WHERE c.name='Starters'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Spring Rolls','Crisp rolls filled with shredded vegetables.',199,'/menu/spring-rolls.jpg',1,1,0,12 FROM categories c WHERE c.name='Starters'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'French Fries','Golden potato fries with a pinch of salt.',129,'/menu/french-fries.jpg',1,1,0,12 FROM categories c WHERE c.name='Starters'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Gobi Manchurian','Crisp cauliflower tossed in a tangy Indo-Chinese sauce.',229,'/menu/gobi-manchurian.jpg',1,1,0,12 FROM categories c WHERE c.name='Starters'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Chicken Tikka','Boneless chicken marinated in yogurt and grilled.',329,'/menu/chicken-tikka.jpg',0,1,0,12 FROM categories c WHERE c.name='Starters'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Tandoori Chicken','Chicken roasted with yogurt and tandoori spices.',349,'/menu/tandoori-chicken.jpg',0,1,0,12 FROM categories c WHERE c.name='Starters'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Chilli Paneer','Paneer tossed with peppers and a spicy sauce.',269,'/menu/chilli-paneer.jpg',1,1,0,12 FROM categories c WHERE c.name='Starters'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Butter Chicken','Tandoori chicken in a creamy tomato-butter gravy.',369,'/menu/butter-chicken.jpg',0,1,1,20 FROM categories c WHERE c.name='Main Course'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Paneer Butter Masala','Paneer cubes in a creamy tomato-cashew gravy.',329,'/menu/paneer-butter-masala.jpg',1,1,1,20 FROM categories c WHERE c.name='Main Course'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Veg Kadai','Mixed vegetables with peppers and roasted kadai spices.',299,'/menu/veg-kadai.jpg',1,1,1,20 FROM categories c WHERE c.name='Main Course'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Palak Paneer','Paneer cubes simmered in a smooth spinach gravy.',319,'/menu/palak-paneer.jpg',1,1,0,20 FROM categories c WHERE c.name='Main Course'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Dal Makhani','Slow-cooked black lentils with butter and cream.',269,'/menu/dal-makhani.jpg',1,1,0,20 FROM categories c WHERE c.name='Main Course'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Dal Tadka','Yellow lentils finished with a fragrant spice tempering.',229,'/menu/dal-tadka.jpg',1,1,0,20 FROM categories c WHERE c.name='Main Course'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Chole Masala','Chickpeas simmered in an onion-tomato masala.',249,'/menu/chole-masala.jpg',1,1,0,20 FROM categories c WHERE c.name='Main Course'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Rajma Masala','Red kidney beans in a rich onion-tomato gravy.',249,'/menu/rajma-masala.jpg',1,1,0,20 FROM categories c WHERE c.name='Main Course'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Aloo Gobi','Potatoes and cauliflower cooked with warming spices.',239,'/menu/aloo-gobi.jpg',1,1,0,20 FROM categories c WHERE c.name='Main Course'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Chicken Curry','Chicken simmered in an aromatic onion-tomato gravy.',339,'/menu/chicken-curry.jpg',0,1,0,20 FROM categories c WHERE c.name='Main Course'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Fish Curry','Fish cooked in a tangy, spiced gravy.',369,'/menu/fish-curry.jpg',0,1,0,20 FROM categories c WHERE c.name='Main Course'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Mutton Rogan Josh','Slow-cooked mutton in a fragrant Kashmiri-style gravy.',449,'/menu/mutton-rogan-josh.jpg',0,1,0,20 FROM categories c WHERE c.name='Main Course'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Garlic Naan','Tandoor-style naan finished with garlic and herbs.',79,'/menu/garlic-naan.jpg',1,1,1,20 FROM categories c WHERE c.name='Breads & Rice'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Butter Naan','Soft naan brushed with butter.',69,'/menu/butter-naan.jpg',1,1,1,20 FROM categories c WHERE c.name='Breads & Rice'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Jeera Rice','Basmati rice tempered with cumin seeds.',179,'/menu/jeera-rice.jpg',1,1,1,20 FROM categories c WHERE c.name='Breads & Rice'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Veg Biryani','Fragrant rice layered with vegetables and spices.',279,'/menu/veg-biryani.jpg',1,1,0,20 FROM categories c WHERE c.name='Breads & Rice'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Chicken Biryani','Spiced chicken layered with fragrant basmati rice.',349,'/menu/chicken-biryani.jpg',0,1,0,20 FROM categories c WHERE c.name='Breads & Rice'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Mutton Biryani','Tender mutton layered with fragrant basmati rice.',429,'/menu/mutton-biryani.jpg',0,1,0,20 FROM categories c WHERE c.name='Breads & Rice'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Steamed Rice','Fluffy steamed white rice.',129,'/menu/steamed-rice.jpg',1,1,0,20 FROM categories c WHERE c.name='Breads & Rice'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Tandoori Roti','Whole-wheat flatbread cooked tandoor-style.',49,'/menu/tandoori-roti.jpg',1,1,0,20 FROM categories c WHERE c.name='Breads & Rice'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Lachha Paratha','Flaky whole-wheat flatbread with crisp layers.',89,'/menu/lachha-paratha.jpg',1,1,0,20 FROM categories c WHERE c.name='Breads & Rice'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Aloo Paratha','Whole-wheat flatbread filled with seasoned potatoes.',129,'/menu/aloo-paratha.jpg',1,1,0,20 FROM categories c WHERE c.name='Breads & Rice'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Veg Fried Rice','Rice stir-fried with vegetables and spring onions.',229,'/menu/veg-fried-rice.jpg',1,1,0,20 FROM categories c WHERE c.name='Breads & Rice'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Lemon Rice','Rice tempered with lemon, curry leaves and peanuts.',179,'/menu/lemon-rice.jpg',1,1,0,20 FROM categories c WHERE c.name='Breads & Rice'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Virgin Mojito','Refreshing mint, lime, soda and ice.',129,'/menu/virgin-mojito.jpg',1,1,1,5 FROM categories c WHERE c.name='Beverages'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Cold Coffee','Chilled coffee blended with creamy milk.',149,'/menu/cold-coffee.jpg',1,1,1,5 FROM categories c WHERE c.name='Beverages'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Fresh Lime Soda','A sparkling lime cooler served over ice.',99,'/menu/fresh-lime-soda.jpg',1,1,1,5 FROM categories c WHERE c.name='Beverages'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Mango Lassi','Creamy yogurt blended with ripe mango.',149,'/menu/mango-lassi.jpg',1,1,0,5 FROM categories c WHERE c.name='Beverages'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Sweet Lassi','A chilled, lightly sweetened yogurt drink.',119,'/menu/sweet-lassi.jpg',1,1,0,5 FROM categories c WHERE c.name='Beverages'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Masala Chai','Milk tea brewed with aromatic Indian spices.',69,'/menu/masala-chai.jpg',1,1,0,5 FROM categories c WHERE c.name='Beverages'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Filter Coffee','South Indian-style brewed coffee with milk.',89,'/menu/filter-coffee.jpg',1,1,0,5 FROM categories c WHERE c.name='Beverages'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Watermelon Juice','Fresh watermelon juice served chilled.',129,'/menu/watermelon-juice.jpg',1,1,0,5 FROM categories c WHERE c.name='Beverages'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Orange Juice','Fresh orange juice with a bright citrus taste.',139,'/menu/orange-juice.jpg',1,1,0,5 FROM categories c WHERE c.name='Beverages'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Lemon Iced Tea','Chilled tea with lemon and ice.',119,'/menu/lemon-iced-tea.jpg',1,1,0,5 FROM categories c WHERE c.name='Beverages'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Chocolate Milkshake','Creamy milk blended with chocolate.',169,'/menu/chocolate-milkshake.jpg',1,1,0,5 FROM categories c WHERE c.name='Beverages'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Strawberry Milkshake','Milk blended with strawberries for a fruity shake.',169,'/menu/strawberry-milkshake.jpg',1,1,0,5 FROM categories c WHERE c.name='Beverages'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Chocolate Lava Cake','Warm chocolate cake with a molten chocolate centre.',189,'/menu/chocolate-lava-cake.jpg',1,1,1,12 FROM categories c WHERE c.name='Desserts'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Royal Kulfi','Traditional Indian kulfi with nuts.',159,'/menu/royal-kulfi.jpg',1,1,1,5 FROM categories c WHERE c.name='Desserts'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Gulab Jamun','Soft milk-solid dumplings soaked in fragrant syrup.',129,'/menu/gulab-jamun.jpg',1,1,1,5 FROM categories c WHERE c.name='Desserts'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Rasmalai','Soft cheese dumplings in sweet saffron milk.',169,'/menu/rasmalai.jpg',1,1,0,5 FROM categories c WHERE c.name='Desserts'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Jalebi','Crisp golden spirals soaked in sugar syrup.',119,'/menu/jalebi.jpg',1,1,0,5 FROM categories c WHERE c.name='Desserts'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Gajar Halwa','Slow-cooked carrot pudding with milk and nuts.',149,'/menu/gajar-halwa.jpg',1,1,0,5 FROM categories c WHERE c.name='Desserts'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Kheer','Creamy rice pudding with cardamom and nuts.',139,'/menu/kheer.jpg',1,1,0,5 FROM categories c WHERE c.name='Desserts'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Vanilla Ice Cream','Classic vanilla ice cream.',99,'/menu/vanilla-ice-cream.jpg',1,1,0,5 FROM categories c WHERE c.name='Desserts'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Chocolate Brownie','Rich chocolate brownie with a soft centre.',169,'/menu/chocolate-brownie.jpg',1,1,0,5 FROM categories c WHERE c.name='Desserts'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Cheesecake','Creamy cheesecake on a crumb biscuit base.',219,'/menu/cheesecake.jpg',1,1,0,5 FROM categories c WHERE c.name='Desserts'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Fruit Salad','A colourful selection of freshly cut seasonal fruit.',149,'/menu/fruit-salad.jpg',1,1,0,5 FROM categories c WHERE c.name='Desserts'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);

INSERT INTO menu_items(category_id,name,description,price,image_url,veg,available,featured,prep_minutes)
SELECT c.id,'Shahi Tukda','Golden fried bread served with sweet thickened milk.',179,'/menu/shahi-tukda.jpg',1,1,0,5 FROM categories c WHERE c.name='Desserts'
ON DUPLICATE KEY UPDATE description=VALUES(description),price=VALUES(price),image_url=VALUES(image_url),veg=VALUES(veg),featured=VALUES(featured),prep_minutes=VALUES(prep_minutes);
