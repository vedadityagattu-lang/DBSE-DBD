# Menu photo credits

58 food photographs are sourced from Wikimedia Commons. Their original authors and licenses are listed below. Veg Kadai and Chocolate Lava Cake are AI-generated illustrative food photos produced for this project. Photos illustrate the dishes and are not photographs of meals served by an actual DINE restaurant.

## Aloo Gobi

- Source: https://commons.wikimedia.org/wiki/File:Gobi-aloo_ki_sabji_by_me,_location_-_my_kitchen,_meerut,_state_-_Uttar_Pradesh,_0002.jpg
- Author: Ifrasaifi12
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/aloo-gobi.jpg

## Aloo Paratha

- Source: https://commons.wikimedia.org/wiki/File:Alooparatha.jpg
- Author: Sankarshan Mukhopadhyay
- License: CC BY-SA 2.0 https://creativecommons.org/licenses/by-sa/2.0
- File: frontend/public/menu/aloo-paratha.jpg

## Butter Chicken

- Source: https://commons.wikimedia.org/wiki/File:Chicken_makhani.jpg
- Author: stu_spivack
- License: CC BY-SA 2.0 https://creativecommons.org/licenses/by-sa/2.0
- File: frontend/public/menu/butter-chicken.jpg

## Butter Naan

- Source: https://commons.wikimedia.org/wiki/File:Butter_Naan_2.jpg
- Author: Ganesh Mohan T
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/butter-naan.jpg

## Cheesecake

- Source: https://commons.wikimedia.org/wiki/File:Plain_cheesecake_slice.jpg
- Author: stu_spivack
- License: CC BY-SA 2.0 https://creativecommons.org/licenses/by-sa/2.0
- File: frontend/public/menu/cheesecake.jpg

## Chicken 65

- Source: https://commons.wikimedia.org/wiki/File:Chicken_65_(Dish).jpg
- Author: Amiyashrivastava
- License: CC BY-SA 3.0 https://creativecommons.org/licenses/by-sa/3.0
- File: frontend/public/menu/chicken-65.jpg

## Chicken Biryani

- Source: https://commons.wikimedia.org/wiki/File:Chicken_Dum_Biryani_03.jpg
- Author: Vis M
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/chicken-biryani.jpg

## Chicken Curry

- Source: https://commons.wikimedia.org/wiki/File:Indian_Curry_Chicken.jpg
- Author: Chowtimes.com
- License: Attribution 
- File: frontend/public/menu/chicken-curry.jpg

## Chicken Tikka

- Source: https://commons.wikimedia.org/wiki/File:Chicken-Tikka.jpg
- Author: Minaxibose1992
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/chicken-tikka.jpg

## Chilli Paneer

- Source: https://commons.wikimedia.org/wiki/File:Chilli_Paneer.JPG
- Author: Arsonarfield
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/chilli-paneer.jpg

## Chocolate Brownie

- Source: https://commons.wikimedia.org/wiki/File:Chocolate_brownies_without_table.jpg
- Author: 
- License: CC BY-SA 3.0 http://creativecommons.org/licenses/by-sa/3.0/
- File: frontend/public/menu/chocolate-brownie.jpg

## Chocolate Milkshake

- Source: https://commons.wikimedia.org/wiki/File:Chocolate_milkshake_..._%F0%9F%98%8B.jpg
- Author: Bernard DUPONT
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/chocolate-milkshake.jpg

## Chole Masala

- Source: https://commons.wikimedia.org/wiki/File:Choleindia.jpg
- Author: kspoddar
- License: CC BY-SA 2.0 https://creativecommons.org/licenses/by-sa/2.0
- File: frontend/public/menu/chole-masala.jpg

## Cold Coffee

- Source: https://commons.wikimedia.org/wiki/File:Iced_coffee_(with_special_milk).jpg
- Author: Ahri.boy
- License: CC BY 4.0 https://creativecommons.org/licenses/by/4.0
- File: frontend/public/menu/cold-coffee.jpg

## Crispy Corn

- Source: https://commons.wikimedia.org/wiki/File:Crispy_corn_made_by_me.jpg
- Author: YKanchan07
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/crispy-corn.jpg

## Dal Makhani

- Source: https://commons.wikimedia.org/wiki/File:Dal_Makhani.jpg
- Author: Charles Haynes
- License: CC BY-SA 2.0 https://creativecommons.org/licenses/by-sa/2.0
- File: frontend/public/menu/dal-makhani.jpg

## Dal Tadka

- Source: https://commons.wikimedia.org/wiki/File:Dal_Tadka-Delhi.jpg
- Author: AugustineKajur
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/dal-tadka.jpg

## Filter Coffee

- Source: https://commons.wikimedia.org/wiki/File:Indian_filter_coffee_in_Dabarah.jpg
- Author: 
- License: CC BY-SA 3.0 http://creativecommons.org/licenses/by-sa/3.0/
- File: frontend/public/menu/filter-coffee.jpg

## Fish Curry

- Source: https://commons.wikimedia.org/wiki/File:South_Indian_Fish_Curry.JPG
- Author: Shreya Shetty
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/fish-curry.jpg

## French Fries

- Source: https://commons.wikimedia.org/wiki/File:French_Fries.JPG
- Author: StockSnap
- License: CC0 http://creativecommons.org/publicdomain/zero/1.0/deed.en
- File: frontend/public/menu/french-fries.jpg

## Fresh Lime Soda

- Source: https://commons.wikimedia.org/wiki/File:Lemon_lime_soda.jpg
- Author: Corn cheese
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/fresh-lime-soda.jpg

## Fruit Salad

- Source: https://commons.wikimedia.org/wiki/File:Fruktsallad_(Fruit_salad).jpg
- Author: dnm
- License: CC BY-SA 3.0 https://creativecommons.org/licenses/by-sa/3.0
- File: frontend/public/menu/fruit-salad.jpg

## Gajar Halwa

- Source: https://commons.wikimedia.org/wiki/File:Gajjar_ka_halwa_(carrot_halwa).JPG
- Author: Prerna Jaddwani
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/gajar-halwa.jpg

## Garlic Naan

- Source: https://commons.wikimedia.org/wiki/File:Garlic_naan_1.jpg
- Author: Joy
- License: CC BY 2.0 https://creativecommons.org/licenses/by/2.0
- File: frontend/public/menu/garlic-naan.jpg

## Gobi Manchurian

- Source: https://commons.wikimedia.org/wiki/File:Gobi_manchurian.jpg
- Author: scaredy_kat
- License: CC BY 2.5 https://creativecommons.org/licenses/by/2.5
- File: frontend/public/menu/gobi-manchurian.jpg

## Gulab Jamun

- Source: https://commons.wikimedia.org/wiki/File:Gulab_jamun_(Gibraltar,_November_2020).jpg
- Author: Cabeza2000
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/gulab-jamun.jpg

## Hara Bhara Kebab

- Source: https://commons.wikimedia.org/wiki/File:Hara_Bhara_kebab_with_cheese.jpg
- Author: SayaniNandy
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/hara-bhara-kebab.jpg

## Jalebi

- Source: https://commons.wikimedia.org/wiki/File:Jalebi_-_Howrah_2014-04-14_0216.JPG
- Author: Biswarup Ganguly
- License: CC BY 3.0 https://creativecommons.org/licenses/by/3.0
- File: frontend/public/menu/jalebi.jpg

## Jeera Rice

- Source: https://commons.wikimedia.org/wiki/File:Jeera_Rice_(only).jpg
- Author: JVRKPRASAD
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/jeera-rice.jpg

## Kheer

- Source: https://commons.wikimedia.org/wiki/File:Rice_Kheer_or_Rice_Pudding.JPG
- Author: Mdsmds0
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/kheer.jpg

## Lachha Paratha

- Source: https://commons.wikimedia.org/wiki/File:Lachha-paratha.jpg
- Author: Sonia Goyal
- License: CC BY-SA 2.0 https://creativecommons.org/licenses/by-sa/2.0
- File: frontend/public/menu/lachha-paratha.jpg

## Lemon Iced Tea

- Source: https://commons.wikimedia.org/wiki/File:Iced_tea_with_mint_and_lemon.jpg
- Author: Peachyeung316
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/lemon-iced-tea.jpg

## Lemon Rice

- Source: https://commons.wikimedia.org/wiki/File:Chitranna_(Lemon_Rice)_prepared_by_an_indian_woman.jpg
- Author: Dahivada
- License: GFDL http://www.gnu.org/copyleft/fdl.html
- File: frontend/public/menu/lemon-rice.jpg

## Mango Lassi

- Source: https://commons.wikimedia.org/wiki/File:Mango-Lassi.jpg
- Author: Kaethe17
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/mango-lassi.jpg

## Masala Chai

- Source: https://commons.wikimedia.org/wiki/File:Masala_Chai.jpg
- Author: Ganesh Mohan T
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/masala-chai.jpg

## Mutton Biryani

- Source: https://commons.wikimedia.org/wiki/File:Mutton_Biryani,_Singapore.jpg
- Author: EurovisionNim
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/mutton-biryani.jpg

## Mutton Rogan Josh

- Source: https://commons.wikimedia.org/wiki/File:Mutton_Rogan_Josh_dish.jpg
- Author: CNEcija12345
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/mutton-rogan-josh.jpg

## Onion Pakora

- Source: https://commons.wikimedia.org/wiki/File:Onion_Pakora.JPG
- Author: Seethabharathi
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/onion-pakora.jpg

## Orange Juice

- Source: https://commons.wikimedia.org/wiki/File:Orange_juice_1_edit1.jpg
- Author: Agency of the United States Department of Agriculture
Edited Version by: Arad
- License: Public domain 
- File: frontend/public/menu/orange-juice.jpg

## Palak Paneer

- Source: https://commons.wikimedia.org/wiki/File:Palak_Paneer_(Cottage_cheese_in_spinach_gravy).jpg
- Author: DreamyFlutura11
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/palak-paneer.jpg

## Paneer Butter Masala

- Source: https://commons.wikimedia.org/wiki/File:Paneer_butter_masala_2.jpg
- Author: Gannu03
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/paneer-butter-masala.jpg

## Paneer Tikka

- Source: https://commons.wikimedia.org/wiki/File:Paneer_Tikka.jpg
- Author: Charles Haynes
- License: CC BY-SA 2.0 https://creativecommons.org/licenses/by-sa/2.0
- File: frontend/public/menu/paneer-tikka.jpg

## Rajma Masala

- Source: https://commons.wikimedia.org/wiki/File:Rajmamasala.jpg
- Author: Monali.mishra
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/rajma-masala.jpg

## Rasmalai

- Source: https://commons.wikimedia.org/wiki/File:Rasa_malai.jpg
- Author: Subhransuphotography
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/rasmalai.jpg

## Royal Kulfi

- Source: https://commons.wikimedia.org/wiki/File:Kulfi_2.jpg
- Author: Gaurav Dhwaj Khadka
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/royal-kulfi.jpg

## Samosa

- Source: https://commons.wikimedia.org/wiki/File:Indian_Samosa_by_clumsy_home_chef.jpg
- Author: ClumsyHomeChef
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/samosa.jpg

## Shahi Tukda

- Source: https://commons.wikimedia.org/wiki/File:Shahi_Tukra.jpg
- Author: Sumit Surai
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/shahi-tukda.jpg

## Spring Rolls

- Source: https://commons.wikimedia.org/wiki/File:Golden_Vegetable_Spring_Rolls_Served_with_Dipping_Sauce.jpg
- Author: Srujanabotcha
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/spring-rolls.jpg

## Steamed Rice

- Source: https://commons.wikimedia.org/wiki/File:Bowl_of_white_rice_01.jpg
- Author: Douglas Perkins
- License: CC0 http://creativecommons.org/publicdomain/zero/1.0/deed.en
- File: frontend/public/menu/steamed-rice.jpg

## Strawberry Milkshake

- Source: https://commons.wikimedia.org/wiki/File:Strawberry_milk_shake_(cropped).jpg
- Author: Renee Comet (Photographer)
- License: Public domain 
- File: frontend/public/menu/strawberry-milkshake.jpg

## Sweet Lassi

- Source: https://commons.wikimedia.org/wiki/File:Sweet_Lassi.JPG
- Author: Krishnam Raju
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/sweet-lassi.jpg

## Tandoori Chicken

- Source: https://commons.wikimedia.org/wiki/File:Chickentandoori.jpg
- Author: kspoddar
- License: CC BY-SA 2.0 https://creativecommons.org/licenses/by-sa/2.0
- File: frontend/public/menu/tandoori-chicken.jpg

## Tandoori Roti

- Source: https://commons.wikimedia.org/wiki/File:Tandoori-rotis.jpg
- Author: Ravi Dwivedi
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/tandoori-roti.jpg

## Vanilla Ice Cream

- Source: https://commons.wikimedia.org/wiki/File:Vanilla_bean_ice_cream_(3086700978).jpg
- Author: a.pasquier from bellingham, washington
- License: CC BY-SA 2.0 https://creativecommons.org/licenses/by-sa/2.0
- File: frontend/public/menu/vanilla-ice-cream.jpg

## Veg Biryani

- Source: https://commons.wikimedia.org/wiki/File:Vegetable_Biryani_IMG_001.jpg
- Author: Phadke09
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/veg-biryani.jpg

## Veg Fried Rice

- Source: https://commons.wikimedia.org/wiki/File:Veg_-_Fried_Rice.jpg
- Author: Naveen piclickz
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/veg-fried-rice.jpg

## Virgin Mojito

- Source: https://commons.wikimedia.org/wiki/File:MojitoReydelmojito.jpg
- Author: Raimonsocial
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/virgin-mojito.jpg

## Watermelon Juice

- Source: https://commons.wikimedia.org/wiki/File:Watermelon_juice_in_a_glass.jpg
- Author: Susan Slater
- License: CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0
- File: frontend/public/menu/watermelon-juice.jpg
