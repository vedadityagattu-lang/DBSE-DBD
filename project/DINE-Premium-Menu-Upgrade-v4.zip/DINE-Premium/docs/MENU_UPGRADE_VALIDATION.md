# v4 Menu upgrade validation

- 60 built-in dishes, 12 per category; all referenced local JPEGs decode successfully.
- Food images inspected against dish names, with replacements for misleading search results.
- React/Vite production build passed.
- Menu upsert statements applied twice against a relational SQLite compatibility fixture: 60 entries, original item IDs, sold-out state and existing order references preserved. The fixture translates MySQL upsert syntax; it does not substitute for running against your MySQL server.
- Python source compilation passed.
- No Presentation page, import, route or navigation link remains in the frontend.

Limits: no live MySQL server or Windows environment was available here. Windows launch and live FastAPI/MySQL flows were not executed. Browser automation was unavailable because the runtime had no installed Chromium executable.
